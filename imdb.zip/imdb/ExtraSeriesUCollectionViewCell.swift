//
//  ExtraSeriesUCollectionViewCell.swift
//  imdb
//
//  Created by maher deeb on 25/07/2017.
//  Copyright © 2017 maher deeb. All rights reserved.
//

import UIKit

class ExtraSeriesUICollectionViewCell: UICollectionViewCell {
    
    @IBOutlet weak var extraImage: UIImageView!
    @IBOutlet weak var extraLabel: UILabel!
    let imagePath = "https://image.tmdb.org/t/p/w300"
    var character : Character?{
        didSet{
            extraLabel.text = character?.actorName
            
            let seriesPhotoUrl = URL(string: imagePath +  (character?.actorImage)! )
            let request = URLRequest(url: seriesPhotoUrl!)
            self.extraImage.image = nil
            URLSession.shared.dataTask(with: request) { (data, response, error) in
                if data != nil {
                    let image = UIImage(data: data!)
                    DispatchQueue.main.async {
                        self.extraImage.image = image
                        
                    }
                    
                }
                }.resume()
        }
    }
    var series : TvShows?{
        didSet{
            extraLabel.text = self.series?.name
            
            let seriesPhotoUrl = URL(string: imagePath + (self.series?.image)! )
            let request = URLRequest(url: seriesPhotoUrl!)
            self.extraImage.image = nil
            URLSession.shared.dataTask(with: request) { (data, response, error) in
                if data != nil {
                    let image = UIImage(data: data!)
                    DispatchQueue.main.async {
                        self.extraImage.image = image
                    }
                    
                }
                }.resume()
        }
    }
   
    
    
        }
        






