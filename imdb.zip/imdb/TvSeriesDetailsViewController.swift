//
//  TvSeriesDetailsViewController.swift
//  imdb
//
//  Created by maher deeb on 21/07/2017.
//  Copyright © 2017 maher deeb. All rights reserved.
//

import UIKit

class TvSeriesDetailsViewController: UIViewController ,UICollectionViewDelegate , UICollectionViewDataSource{
    
    
    @IBOutlet weak var creatorLabel: UILabel!
    @IBOutlet weak var releasetDate: UILabel!
    
    @IBOutlet weak var episodeEnds: UILabel!
    @IBOutlet weak var rating: UILabel!
    
    @IBOutlet weak var seriesOverView: UITextView!
    @IBOutlet weak var geners: UILabel!
    @IBOutlet weak var numberOfEpisodes: UILabel!
    @IBOutlet weak var numberOfSeasons: UILabel!
    
    @IBOutlet weak var seriesImage: UIImageView!
    
    @IBOutlet weak var extraSeriesCollectionView: UICollectionView!
    @IBOutlet weak var backGround: UIImageView!
    var series : TvShows?
    var segmentIndex : Int = 0
    var count : Int = 0
    let imagePath = "https://image.tmdb.org/t/p/original"
    let seriesPath = "https://www.youtube.com/watch?v="
    var currentPage = 1
    override func viewDidLoad() {
        super.viewDidLoad()
        self.title = self.series?.name
        
        self.navigationItem.hidesBackButton = true
        let newBackButton = UIBarButtonItem(title: "Back", style: UIBarButtonItemStyle.plain, target: self, action: #selector(TvSeriesDetailsViewController.back(sender:)))
        self.navigationItem.leftBarButtonItem = newBackButton

        
    }
    
    
    override func viewWillAppear(_ animated: Bool) {
        
        ApiHandler.shared.getSeriesDetails(series: series!){
            if self.series?.createdBy != nil{
                 self.creatorLabel.text =  "Created By: \n" + (self.series?.createdBy)!
            }
           
            self.releasetDate.text =   "Released Date: \n" + (self.series?.firstAirDate)!
            self.episodeEnds.text =  "Last Episode: \n" + (self.series?.lastAirDate)!
            self.rating.text = "Rating: \n\(self.series!.rating)"
            self.geners.text = "Gener: \n" + (self.series?.geners)!
            self.numberOfEpisodes.text = "Number Of Episodes: \n\(self.series!.numberOfEpisodes)"
            self.numberOfSeasons.text = "Season Numbers: \n\(self.series!.numberOfSeasons)"
            self.seriesOverView.text = self.series?.overView
            self.seriesImage.image = nil
            
            let seriesPhotoUrl = URL(string: self.imagePath + "/" + (self.series?.image)! )
            let request = URLRequest(url: seriesPhotoUrl!)
            URLSession.shared.dataTask(with: request) { (data, response, error) in
                if data != nil {
                    let image = UIImage(data: data!)
                    DispatchQueue.main.async {
                        self.seriesImage.image = image
                    }
                }
                }.resume()
            let seriesBackGroundPhotoUrl = URL(string: self.imagePath  + (self.series?.backGround)! )
            let backGroundrequest = URLRequest(url: seriesBackGroundPhotoUrl!)
            URLSession.shared.dataTask(with: backGroundrequest) { (data, response, error) in
                if data != nil {
                    let image = UIImage(data: data!)
                    DispatchQueue.main.async {
                        self.backGround.image = image
                    }
                }else{
                    self.backGround.backgroundColor = .white
                }
                }.resume()
        }
        
        ApiHandler.shared.getSeriesCharacters(series :series!){
            self.extraSeriesCollectionView.reloadData()}
        ApiHandler.shared.getSimilarSeries(page: currentPage , series :series!){
            self.extraSeriesCollectionView.reloadData()}
         ApiHandler.shared.TvSeriesCharacters.removeAll()
        ApiHandler.shared.tvSimSeries.removeAll()
    }
    
    @IBAction func seriesTrailer(_ sender: UIButton) {
        
        ApiHandler.shared.getSeriesTrailers(series: series!)
        {
            if self.series?.trailer != nil{
                if let url = NSURL(string: self.seriesPath + (self.series?.trailer)!){
                    UIApplication.shared.openURL(url as URL)
                }

            }else{
                let alertController = UIAlertController(title: "Sorry", message:
                    "We Don't Have a trailer", preferredStyle: UIAlertControllerStyle.alert)
                alertController.addAction(UIAlertAction(title: "Dismiss", style: UIAlertActionStyle.default,handler: nil))
                
                self.present(alertController, animated: true, completion: nil)
            }

                    }
    }
    
    
    @IBAction func extrasSelectionSegmentedControl(_ sender: UISegmentedControl) {
        switch sender.selectedSegmentIndex {
            
        case 0 : segmentIndex = sender.selectedSegmentIndex
        ApiHandler.shared.TvSeriesCharacters.removeAll()
        
        ApiHandler.shared.getSeriesCharacters(series :series!){
            self.extraSeriesCollectionView.reloadData()
            
        }
            break
        case 1 : segmentIndex = sender.selectedSegmentIndex
        
        ApiHandler.shared.tvSimSeries.removeAll()
        
        
        ApiHandler.shared.getSimilarSeries(page: currentPage, series :series!){
            self.extraSeriesCollectionView.reloadData()
        }
        
            break
            
        default : break
        }
    }
    
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int ) -> Int {
        
        switch  segmentIndex {
        case 0:  count =  ApiHandler.shared.TvSeriesCharacters.count
        
        
            break
        case 1:  count =  ApiHandler.shared.tvSimSeries.count
        
            break
            default: break
        }
        
        return count
    }
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        
        var cell = collectionView.dequeueReusableCell(withReuseIdentifier: "charaterSeriesCell", for: indexPath) as! ExtraSeriesUICollectionViewCell
        switch  segmentIndex {
        case 0 :
            
            let ToShow = ApiHandler.shared.TvSeriesCharacters[indexPath.row]
            cell.character = ToShow
            
            break
        case 1: cell = collectionView.dequeueReusableCell(withReuseIdentifier: "similarSeriesCell", for: indexPath) as! ExtraSeriesUICollectionViewCell
            let ToShow = ApiHandler.shared.tvSimSeries[indexPath.row]
        cell.series = ToShow
        
            break
                   
        default: break
        }
        
        return cell
        
    }
    func collectionView(_ collectionView: UICollectionView, willDisplay cell: UICollectionViewCell, forItemAt indexPath: IndexPath) {
       if indexPath.row == ApiHandler.shared.tvSimSeries.count - 1
        {
            currentPage += 1
            ApiHandler.shared.getSimilarSeries(page: currentPage, series :series! ){
                self.extraSeriesCollectionView.reloadData()
            }
            
        }

    }
    
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        switch segmentIndex {
        case 0:
            if let characterViewController = segue.destination as? CharacterViewController {
            let character = ApiHandler.shared.TvSeriesCharacters[(extraSeriesCollectionView.indexPathsForSelectedItems?.first?.row)!]
            characterViewController.character = character
        }
            break
        case 1: if let similarSeriesViewController = segue.destination as? TvSeriesDetailsViewController {
            let series = ApiHandler.shared.tvSimSeries[(extraSeriesCollectionView.indexPathsForSelectedItems?.first?.row)!]
            similarSeriesViewController.series = series
            
            }
            
            
        default:
            break
        }
        
    }
    func back(sender: UIBarButtonItem) {
        // Perform your custom actions
        // ...
        // Go back to the previous ViewController
        let switchViewController = self.navigationController?.viewControllers[0] as! TvSeriesViewController
        
        self.navigationController?.popToViewController(switchViewController, animated: true)    }
    
    


    
    
}
