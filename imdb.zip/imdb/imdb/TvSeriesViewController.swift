//
//  TvSeriesViewController.swift
//  imdb
//
//  Created by maher deeb on 21/07/2017.
//  Copyright © 2017 maher deeb. All rights reserved.
//

import UIKit
import CoreData

class TvSeriesViewController: UIViewController ,UICollectionViewDataSource,UICollectionViewDelegate , UISearchBarDelegate , UIPickerViewDelegate, UIPickerViewDataSource {
    var refresher : UIRefreshControl!
    @IBOutlet weak var tvSeriesCollectionView: UICollectionView!
    @IBOutlet weak var picker: UIPickerView!
    
    @IBOutlet weak var tvSeriesSearch: UISearchBar!
    var searchArray : [TvShows]?
    var searchActive = false
    var currentPage = 1
    var category : [String ] = ["Popular TvShows" ,"Top Rated TvShows"]
    var rowPicker = 0
    override func viewDidLoad() {
        super.viewDidLoad()
        
        self.tvSeriesSearch.delegate = self
        
        loadAndRefreshData()
        refresher = UIRefreshControl()
        refresher.attributedTitle = NSAttributedString(string: "Pull To refresh")
        refresher.addTarget(self, action: #selector(TvSeriesViewController.loadAndRefreshData), for: UIControlEvents.valueChanged)
        tvSeriesCollectionView.addSubview(refresher)
        
       
    }
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        if searchActive{
            return (searchArray!.count)
        }else{
            
            return ApiHandler.shared.tvSreies.count
        }
    }
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "tvSeriesCell", for: indexPath) as! TvSeriesCollectionViewCell
        if searchActive{
            let tvToShow = searchArray?[indexPath.row]
            
            cell.tvSeries = tvToShow
            
        }else{
            
            let tvToShow = ApiHandler.shared.tvSreies[indexPath.row]
            
            cell.tvSeries = tvToShow
        }
        return cell
        
    }
    func collectionView(_ collectionView: UICollectionView, willDisplay cell: UICollectionViewCell, forItemAt indexPath: IndexPath){
        switch rowPicker {
        case 0: if indexPath.row == ApiHandler.shared.tvSreies.count - 1
        {
            currentPage += 1
            ApiHandler.shared.getPopularTvSeries(page: currentPage ){
                self.tvSeriesCollectionView.reloadData()
            }
            
            }
        case 1 : if indexPath.row == ApiHandler.shared.tvSreies.count - 1
        {
            currentPage += 1
            ApiHandler.shared.topRatedSeries(page: currentPage ){
                self.tvSeriesCollectionView.reloadData()
            }
            }
        default : break
        }
        tvSeriesCollectionView.keyboardDismissMode = .onDrag
    }
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        let tvSeriesDetaileViewController = segue.destination as! TvSeriesDetailsViewController
        if searchActive{
            let selectedTvSeries = searchArray?[(tvSeriesCollectionView.indexPathsForSelectedItems?.first?.row)!]
            tvSeriesDetaileViewController.series = selectedTvSeries
        }else{
            let selectedTvSeries = ApiHandler.shared.tvSreies[(tvSeriesCollectionView.indexPathsForSelectedItems?.first?.row)!]
            
            tvSeriesDetaileViewController.series = selectedTvSeries
            
        }
    }
    @IBAction func buttonTapped(_ sender: UIBarButtonItem) {
        if  picker.isHidden{
            picker.isHidden = false
            
            
        }else{
            picker.isHidden = true
        }
    }
    
    
    @IBAction func searchTapped(_ sender: UIBarButtonItem) {
        if  tvSeriesSearch.isHidden{
            tvSeriesSearch.isHidden = false
            
        }else{
            tvSeriesSearch.isHidden = true
        }
    }
    func numberOfComponents(in pickerView: UIPickerView) -> Int {
        return 1
    }
    func pickerView(_ pickerView: UIPickerView, numberOfRowsInComponent component: Int) -> Int{
        return category.count
    }
    
    func pickerView(_ pickerView: UIPickerView, titleForRow row: Int, forComponent component: Int) -> String? {
        return category[row]
    }
    func pickerView(_ pickerView: UIPickerView, didSelectRow row: Int, inComponent component: Int)
    {
        rowPicker = row
        self.title = category[row]
        currentPage = 1
        switch rowPicker {
        case 0 : loadDataFromApi(cases : 0)
            break
        case 1 : loadDataFromApi(cases : 1)
            break
        default:
            break
        }
        self.picker.isHidden = true
    }
    
    func searchBarCancelButtonClicked(_ searchBar: UISearchBar) {
        
        tvSeriesSearch.text = ""
        tvSeriesSearch.resignFirstResponder()
        tvSeriesSearch.isHidden = true
        searchActive = false
        self.tvSeriesCollectionView.reloadData()
    }
    
    func searchBar(_ searchBar: UISearchBar, textDidChange searchText: String) {
        
        searchArray = ApiHandler.shared.tvSreies.filter({ ($0.name?.lowercased().contains(searchText.lowercased()))!
            
        })
        if(searchArray?.count == 0){
            searchActive = false;
        } else {
            searchActive = true;
        }
        self.tvSeriesCollectionView.reloadData()
    }
    
    func loadAndRefreshData()
    {
        currentPage = 1
        switch rowPicker{
        case 0 : loadDataFromApi(cases : 0)
            break
        case 1 : loadDataFromApi(cases : 1)
            break
        default : break
        }
    }
    
    func loadDataFromApi(cases : Int){
        switch cases{
        case 0: ApiHandler.shared.tvSreies.removeAll()
                ApiHandler.shared.getPopularTvSeries(page: currentPage){
                self.tvSeriesCollectionView.reloadData()
                self.refresher.endRefreshing()
                }

        case 1: ApiHandler.shared.tvSreies.removeAll()
                self.tvSeriesCollectionView.reloadData()
                ApiHandler.shared.topRatedSeries(page: currentPage){
                self.tvSeriesCollectionView.reloadData()
                self.refresher.endRefreshing()
                }

        default : break
        }
    }
    
}
