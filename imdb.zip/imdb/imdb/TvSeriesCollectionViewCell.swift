//
//  TvSeriesCollectionViewCell.swift
//  imdb
//
//  Created by maher deeb on 21/07/2017.
//  Copyright © 2017 maher deeb. All rights reserved.
//

import UIKit

class TvSeriesCollectionViewCell: UICollectionViewCell {
    @IBOutlet weak var tvSeriesImageView: UIImageView!
    @IBOutlet weak var tvSeriesTitleLable: UILabel!
    @IBOutlet weak var ratingtvSeriesLable: UILabel!
    
    let imagePath = "https://image.tmdb.org/t/p/w300/"
    
    var tvSeries : TvShows? {
        didSet{
            tvSeriesTitleLable.text = tvSeries?.name
            ratingtvSeriesLable.text =  "\(tvSeries!.rating)"
            
            self.tvSeriesImageView.image = nil
            let moviePhotoUrl = URL(string: imagePath + (tvSeries?.image)! )
            let request = URLRequest(url: moviePhotoUrl!)
            URLSession.shared.dataTask(with: request) { (data, response, error) in
                if data != nil {
                    let image = UIImage(data: data!)
                    DispatchQueue.main.async {
                        self.tvSeriesImageView.image = image
                        
                        
                    }
                    
                }
                }.resume()
            
        }
    }
}
