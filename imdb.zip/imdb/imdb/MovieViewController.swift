//
//  ViewController.swift
//  imdb
//
//  Created by maher deeb on 02/07/2017.
//  Copyright © 2017 maher deeb. All rights reserved.
//

import UIKit
import CoreData



class MovieViewController: UIViewController ,UISearchBarDelegate, UICollectionViewDataSource,UICollectionViewDelegate, UIPickerViewDelegate, UIPickerViewDataSource   {
    
    @IBOutlet weak var movieCollectionView: UICollectionView!
    var refresher : UIRefreshControl!
    
    @IBOutlet weak var search: UISearchBar!
    @IBOutlet weak var picker: UIPickerView!
    var category : [String ] = ["Popular Movies" , "Now Playing Movies" , "Top Rated Movies" , "Up Coming Movies"]
    var currentPage : Int = 1
    var searchArray : [Movie]?
    var searchActive = false
    var rowPicker : Int = 0
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        self.search.delegate = self
        
        loadAndRefreshData()
        self.title = self.category[0]
        refresher = UIRefreshControl()
        refresher.attributedTitle = NSAttributedString(string: "Pull To refresh")
        refresher.addTarget(self, action: #selector(MovieViewController.loadAndRefreshData), for: UIControlEvents.valueChanged)
        movieCollectionView.addSubview(refresher)
        
        
    }
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        
        if searchActive{
            return searchArray!.count
        }else{
            return ApiHandler.shared.movies.count
        }
        
    }
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "movieCell", for: indexPath) as! MoviesCollectionViewCell
        if searchActive{
            let movieToShow = searchArray?[indexPath.row]
            
            cell.movie = movieToShow
            
        }else{
            let movieToShow = ApiHandler.shared.movies[indexPath.row]
            
            cell.movie = movieToShow
        }
        
        
        return cell
        
    }
    
    func collectionView(_ collectionView: UICollectionView, willDisplay cell: UICollectionViewCell, forItemAt indexPath: IndexPath){
        switch self.rowPicker {
        case 0:
            
                if indexPath.row == ApiHandler.shared.movies.count - 1
        {
            self.currentPage += 1
            
           
            ApiHandler.shared.getPopularMovies(page: self.currentPage ){
                
                self.movieCollectionView.reloadData()
            }
            
                }
            break
        case 1 : if indexPath.row == ApiHandler.shared.movies.count - 1
        {
            self.currentPage += 1
            ApiHandler.shared.nowPlayingMovies(page: self.currentPage ){
                self.movieCollectionView.reloadData()
            }
        }
            break
        case 2 :  if indexPath.row == ApiHandler.shared.movies.count - 1
        {
            self.currentPage += 1
            ApiHandler.shared.topRatedMovies(page: self.currentPage ){
                self.movieCollectionView.reloadData()
            }
        }
            break
        case 3 :
            if indexPath.row == ApiHandler.shared.movies.count - 1
            {
                self.currentPage += 1
                ApiHandler.shared.upComingMovies(page: self.currentPage ){
                    self.movieCollectionView.reloadData()
                }
            }
            break
            
        default : break
        }
        movieCollectionView.keyboardDismissMode = .onDrag
    }
    
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        let movieDetaileViewController = segue.destination as! MovieDetailsViewController
        if searchActive{
            let selectedMovie = searchArray?[(movieCollectionView.indexPathsForSelectedItems?.first?.row)!]
            
            movieDetaileViewController.movie = selectedMovie
        }else{
            let selectedMovie = ApiHandler.shared.movies[(movieCollectionView.indexPathsForSelectedItems?.first?.row)!]
            
            movieDetaileViewController.movie = selectedMovie
            
        }
    }
    
    @IBAction func buttonTapped(_ sender: UIBarButtonItem) {
        if  picker.isHidden{
            picker.isHidden = false
            
            
        }else{
            picker.isHidden = true
        }
    }
    func numberOfComponents(in pickerView: UIPickerView) -> Int {
        return 1
    }
    func pickerView(_ pickerView: UIPickerView, numberOfRowsInComponent component: Int) -> Int{
        return category.count
    }
    
    func pickerView(_ pickerView: UIPickerView, titleForRow row: Int, forComponent component: Int) -> String? {
        return category[row]
    }
    func pickerView(_ pickerView: UIPickerView, didSelectRow row: Int, inComponent component: Int)
    {
        rowPicker = row
        currentPage = 1
        self.title = category[row]
        
        switch rowPicker {
        case 0 : loadDatafromApi(cases : 0)
            break
        case 1 : loadDatafromApi(cases : 1)
            break
        case 2 : loadDatafromApi(cases : 2)
            break
        case 3 : loadDatafromApi(cases : 3)
            break
        default:
            break
        }
        self.picker.isHidden = true
    }
    @IBAction func searchTapped(_ sender: UIBarButtonItem) {
        if  search.isHidden{
            search.isHidden = false
            
        }else{
            search.isHidden = true
        }
    }
    
    func searchBarCancelButtonClicked(_ searchBar: UISearchBar) {
        
        search.text = ""
        search.resignFirstResponder()
        search.isHidden = true
        
        searchActive = false
      
        self.movieCollectionView.reloadData()
        
        
    }
    func searchBar(_ searchBar: UISearchBar, textDidChange searchText: String) {
        
        searchArray = ApiHandler.shared.movies.filter({ ($0.title?.lowercased().contains(searchText.lowercased()))!
            
        })
        if(searchArray?.count == 0){
            searchActive = false;
        } else {
            searchActive = true;
        }
        self.movieCollectionView.reloadData()
        
    }
    
    func loadAndRefreshData()
    {
        currentPage = 1
        switch rowPicker{
        case 0 : loadDatafromApi(cases : 0)
            break
        case 1 : loadDatafromApi(cases : 1)
            break
        case 2 : loadDatafromApi(cases : 2)
            break
        case 3 : loadDatafromApi(cases : 3)
            break
        default:
            break
        }
        
    }
    func loadDatafromApi(cases : Int){
        switch cases {
        case 0: ApiHandler.shared.movies.removeAll()
        ApiHandler.shared.getPopularMovies(page: currentPage){
            self.movieCollectionView.reloadData()
            self.refresher.endRefreshing()
            }
        case 1: ApiHandler.shared.movies.removeAll()
        self.movieCollectionView.reloadData()
        ApiHandler.shared.nowPlayingMovies(page: currentPage) {
            self.movieCollectionView.reloadData()
            self.refresher.endRefreshing()
            }
        case 2: ApiHandler.shared.movies.removeAll()
        self.movieCollectionView.reloadData()
        ApiHandler.shared.topRatedMovies(page: currentPage) {
            self.movieCollectionView.reloadData()
            self.refresher.endRefreshing()
            }
        case 3: ApiHandler.shared.movies.removeAll()
        self.movieCollectionView.reloadData()
        ApiHandler.shared.upComingMovies(page: currentPage){
            self.movieCollectionView.reloadData()
            self.refresher.endRefreshing()
            }
        default: break
            
        }
    }
    
    
}



