//
//  MoviesCollectionViewCell.swift
//  imdb
//
//  Created by maher deeb on 07/07/2017.
//  Copyright © 2017 maher deeb. All rights reserved.
//

import UIKit

class MoviesCollectionViewCell: UICollectionViewCell {
    
    @IBOutlet weak var movieImageView: UIImageView!
    @IBOutlet weak var movieTitleLable: UILabel!
    @IBOutlet weak var ratingMovieLable: UILabel!
    
    let imagePath = "https://image.tmdb.org/t/p/w300/"
    
    var movie : Movie? {
        didSet{
            movieTitleLable.text = movie?.title
            ratingMovieLable.text =  "\(movie!.rating)"
            
            self.movieImageView.image = nil
            let moviePhotoUrl = URL(string: imagePath + (movie?.posterPath)! )
            let request = URLRequest(url: moviePhotoUrl!)
            URLSession.shared.dataTask(with: request) { (data, response, error) in
                if data != nil {
                    let image = UIImage(data: data!)
                    DispatchQueue.main.async {
                        self.movieImageView.image = image
                        
                        
                    }
                    
                }
                }.resume()
            
            
            
            
        }
    }
    
    
    
}
