//
//  TvSeriesDetailsViewController.swift
//  imdb
//
//  Created by maher deeb on 21/07/2017.
//  Copyright © 2017 maher deeb. All rights reserved.
//

import UIKit

class TvSeriesDetailsViewController: UIViewController ,UICollectionViewDelegate , UICollectionViewDataSource {

    @IBOutlet weak var seriesName: UILabel!
    
    @IBOutlet weak var releasedDate: UILabel!
    @IBOutlet weak var seriesRating: UILabel!
    @IBOutlet weak var seriesGeners: UILabel!
    @IBOutlet weak var seriesLanguage: UILabel!
    @IBOutlet weak var productionCompany: UILabel!
    @IBOutlet weak var seriesOverView: UITextView!
    @IBOutlet weak var posterImage: UIImageView!
    @IBOutlet var seriesUI: UIView!
    @IBOutlet weak var extraCollectionView: UICollectionView!
    
    
    
    var series : TvShows?
    var character : Character?
    var segmentIndex : Int = 0
    var count : Int = 0
    var simMovie : SimilarMovies?
    let imagePath = "https://image.tmdb.org/t/p/original"
    let moviePath = "https://www.youtube.com/watch?v="
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        
        
        
    }
    
    
    override func viewWillAppear(_ animated: Bool) {
        
        ApiHandler.shared.getMovieDetails(movie: movie!){
            self.seriesName.text =  self.movie?.title
//            self.ifReleased.text =   self.movie?.status
            self.releasedDate.text =  self.movie?.releaseDate
            self.seriesRating.text = "\(self.movie!.rating)"
            self.seriesLanguage.text = self.movie?.spokenLanguage
            self.seriesOverView.text = self.movie?.overView
            self.seriesLanguage.text = "Movie Language: " + (self.movie?.originalLaguage)!
            self.productionCompany.text = self.movie?.companies
            self.seriesGeners.text = self.movie?.geners
            
            self.posterImage.image = nil
            let moviePhotoUrl = URL(string: self.imagePath + "/" + (self.movie?.posterPath)! )
            let request = URLRequest(url: moviePhotoUrl!)
            URLSession.shared.dataTask(with: request) { (data, response, error) in
                if data != nil {
                    let image = UIImage(data: data!)
                    DispatchQueue.main.async {
                        self.posterImage.image = image
                    }
                }
                }.resume()
        }
        
        ApiHandler.shared.getMovieCharacters(movie: movie!){
            self.extraCollectionView.reloadData()}
        ApiHandler.shared.getSimilarMovies(movie: movie!){
            self.extraCollectionView.reloadData()}
        ApiHandler.shared.characters.removeAll()
        ApiHandler.shared.similarMovies.removeAll()
        
        
        
    }
    
    @IBAction func movieTrailer(_ sender: UIButton) {
        
        ApiHandler.shared.getMovieTrailers(movie: movie!)
        {
            if let url = NSURL(string: self.moviePath + (self.movie?.trailer)!){
                UIApplication.shared.openURL(url as URL)
            }
        }
    }
    
    @IBAction func extrasSelectionSegmentedControl(_ sender: UISegmentedControl) {
        switch sender.selectedSegmentIndex {
            
        case 0 : segmentIndex = sender.selectedSegmentIndex
        ApiHandler.shared.characters.removeAll()
        
        ApiHandler.shared.getMovieCharacters(movie: movie!){
            self.extraCollectionView.reloadData()
            
        }
            break
        case 1 : segmentIndex = sender.selectedSegmentIndex
        
        ApiHandler.shared.similarMovies.removeAll()
        
        
        ApiHandler.shared.getSimilarMovies(movie: movie!){
            self.extraCollectionView.reloadData()
        }
        
            break
        case 2 : segmentIndex = sender.selectedSegmentIndex
            
        default : break
        }
    }
    
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int ) -> Int {
        
        switch  segmentIndex {
        case 0:  count =  ApiHandler.shared.characters.count
        
        
            break
        case 1:  count =  ApiHandler.shared.similarMovies.count
        
            break
        default: break
        }
        
        return count
    }
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "extraCell", for: indexPath) as! extraCellCollectionViewCell
        switch  segmentIndex {
        case 0 :
            let ToShow = ApiHandler.shared.characters[indexPath.row]
            cell.character = ToShow
            
            break
        case 1: let ToShow = ApiHandler.shared.similarMovies[indexPath.row]
        cell.movie = ToShow
        
            break
            
        default: break
        }
        
        return cell
        
    }
    
    
    
}
