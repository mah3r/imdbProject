//
//  MovieDetailsViewController.swift
//  imdb
//
//  Created by maher deeb on 09/07/2017.
//  Copyright © 2017 maher deeb. All rights reserved.
//

import UIKit


class MovieDetailsViewController: UIViewController ,UICollectionViewDelegate , UICollectionViewDataSource   {
    
    @IBOutlet weak var ifReleased: UILabel!
    @IBOutlet weak var releasedDate: UILabel!
    @IBOutlet weak var movieRating: UILabel!
    @IBOutlet weak var movieGeners: UILabel!
    @IBOutlet weak var movieLanguage: UILabel!
    @IBOutlet weak var productionCompany: UILabel!
    @IBOutlet weak var movieOverView: UITextView!
    @IBOutlet weak var posterImage: UIImageView!
    @IBOutlet var movieUI: UIView!
    @IBOutlet weak var extraCollectionView: UICollectionView!
    
    @IBOutlet weak var backGround: UIImageView!
    
    
    var movie : Movie?
    var character : Character?
    var segmentIndex : Int = 0
    var count : Int = 0
    var simMovie : Movie?
    let imagePath = "https://image.tmdb.org/t/p/w300"
    let moviePath = "https://www.youtube.com/watch?v="
    var currentPage = 1
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        self.title = self.movie?.title
        
        self.navigationItem.hidesBackButton = true
        let newBackButton = UIBarButtonItem(title: "Back", style: UIBarButtonItemStyle.plain, target: self, action: #selector(MovieDetailsViewController.back(sender:)))
        self.navigationItem.leftBarButtonItem = newBackButton
        
          }
    
    
    override func viewWillAppear(_ animated: Bool) {
        
        
        self.navigationController?.navigationBar.barTintColor = UIColor.white
        self.navigationController?.navigationBar.tintColor = UIColor.blue
        self.navigationController!.navigationBar.titleTextAttributes = [NSForegroundColorAttributeName: UIColor.red]
        
        ApiHandler.shared.getMovieDetails(movie: movie!){
            
            self.ifReleased.text =   "Status: \n" + (self.movie?.status)!
            self.releasedDate.text =  "Release Date: \n" + (self.movie?.releaseDate)!
            self.movieRating.text = "Rating: \n\(self.movie!.rating)"
            self.movieOverView.text = self.movie?.overView
            self.movieLanguage.text = "Movie Language: \n" + (self.movie?.originalLaguage)!
            self.productionCompany.text = "Production Compnie: \n" + (self.movie?.companies)!
            self.movieGeners.text = "Gener: \n" + (self.movie?.geners)!
            
            self.posterImage.image = nil
            let moviePhotoUrl = URL(string: self.imagePath  + (self.movie?.posterPath)! )
            let request = URLRequest(url: moviePhotoUrl!)
            URLSession.shared.dataTask(with: request) { (data, response, error) in
                if data != nil {
                    let image = UIImage(data: data!)
                    DispatchQueue.main.async {
                        self.posterImage.image = image
                    }
                }
                }.resume()
            if self.movie?.backGroundImage != nil{
                let moviePhotoBackGroundUrl = URL(string: self.imagePath + (self.movie?.backGroundImage)! )
                let requestBackGround = URLRequest(url: moviePhotoBackGroundUrl!)
                URLSession.shared.dataTask(with: requestBackGround) { (data, response, error) in
                    if data != nil {
                        let image = UIImage(data: data!)
                        DispatchQueue.main.async {
                            self.backGround.image = image
                            
                        }
                    }
                    }.resume()
            }
        }
        ApiHandler.shared.getMovieCharacters(movie: movie!){
            self.extraCollectionView.reloadData()}
        ApiHandler.shared.getSimilarMovies(page: currentPage, movie: movie!){
            self.extraCollectionView.reloadData()}
        ApiHandler.shared.characters.removeAll()
        ApiHandler.shared.similarMovies.removeAll()
        
        
        
    }
    
    @IBAction func movieTrailer(_ sender: UIButton) {
        
        ApiHandler.shared.getMovieTrailers(movie: movie!)
        {
            if self.movie?.trailer != nil{
                if let url = NSURL(string: self.moviePath + (self.movie?.trailer)!) {
                    UIApplication.shared.openURL(url as URL)
                }
                
            }
            else{
                let alertController = UIAlertController(title: "Sorry", message:
                    "We Don't Have a trailer", preferredStyle: UIAlertControllerStyle.alert)
                alertController.addAction(UIAlertAction(title: "Dismiss", style: UIAlertActionStyle.default,handler: nil))
                
                self.present(alertController, animated: true, completion: nil)
            }
        }
        
    }
    
    @IBAction func extrasSelectionSegmentedControl(_ sender: UISegmentedControl) {
        switch sender.selectedSegmentIndex {
            
        case 0 : segmentIndex = sender.selectedSegmentIndex
        ApiHandler.shared.characters.removeAll()
        ApiHandler.shared.getMovieCharacters(movie: movie!){
            self.extraCollectionView.reloadData()
            
        }
            break
        case 1 : segmentIndex = sender.selectedSegmentIndex
        ApiHandler.shared.similarMovies.removeAll()
        ApiHandler.shared.getSimilarMovies(page: currentPage, movie: movie!){
            self.extraCollectionView.reloadData()
        }
        
            break
        default : break
        }
    }
    
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int ) -> Int {
        
        switch  segmentIndex {
        case 0:  count =  ApiHandler.shared.characters.count
        
        
            break
        case 1:  count =  ApiHandler.shared.similarMovies.count
        
            break
        default : break
        }
        
        return count
    }
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        var cell = collectionView.dequeueReusableCell(withReuseIdentifier: "characterCell", for: indexPath) as! ExtraCellCollectionViewCell
        
        switch  segmentIndex {
        case 0 :
            let ToShow = ApiHandler.shared.characters[indexPath.row]
            cell.character = ToShow
            
            
            break
        case 1:
            cell = collectionView.dequeueReusableCell(withReuseIdentifier: "similarCell", for: indexPath) as! ExtraCellCollectionViewCell
            let ToShow = ApiHandler.shared.similarMovies[indexPath.row]
            cell.movie = ToShow
            
            break
        default: break
        }
        return cell
    }
    func collectionView(_ collectionView: UICollectionView, willDisplay cell: UICollectionViewCell, forItemAt indexPath: IndexPath) {
        if indexPath.row == ApiHandler.shared.similarMovies.count - 1
        {
            currentPage += 1
            ApiHandler.shared.getSimilarMovies(page: currentPage, movie: movie! ){
                self.extraCollectionView.reloadData()
            }
            
        }
    }
    
    
    
    
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        switch segmentIndex {
        case 0:  if let characterViewController = segue.destination as? CharacterViewController {
            let character = ApiHandler.shared.characters[(extraCollectionView.indexPathsForSelectedItems?.first?.row)!]
            characterViewController.character = character
        }
            break
        case 1: if let similarMovieViewController = segue.destination as? MovieDetailsViewController {
            let movie = ApiHandler.shared.similarMovies[(extraCollectionView.indexPathsForSelectedItems?.first?.row)!]
            similarMovieViewController.movie = movie
            
            }
            
        default:
            break
        }
        
    }
    
    
    func back(sender: UIBarButtonItem) {
              let switchViewController = self.navigationController?.viewControllers[0] as! MovieViewController
        
        self.navigationController?.popToViewController(switchViewController, animated: true)    }
    
    
}
