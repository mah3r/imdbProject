//
//  ApiHandler.swift
//  imdb
//
//  Created by maher deeb on 07/07/2017.
//  Copyright © 2017 maher deeb. All rights reserved.
//

import Foundation
import  CoreData
import UIKit
class ApiHandler {
    static var shared = ApiHandler()
    
    var movies : [Movie]=[]
    var characters : [Character] = []
    var TvSeriesCharacters : [Character] = []
    var similarMovies : [Movie] = []
    var tvSimSeries : [TvShows] = []
    var tvSreies : [TvShows] = []
    var context : NSManagedObjectContext! = nil
    

    
    private let apiKey = "?api_key=c57d017703e9070608b560bce22526ae"
    private let baseUrl = "https://api.themoviedb.org/3/"
    private let movieUrl = "movie/"
    private let tvShowUrl = "tv/"
    private let personInfoUrl = "person/"
    private let popularUrl = "popular"
    private let nowPlaying = "now_playing"
    private let topRated = "top_rated"
    private let upComing = "upcoming"
    private var sim = "/similar"
    private let credit = "/credits"
    var popPages : Int = 0
    
    
    private init() {
        if let appDelegate = UIApplication.shared.delegate as? AppDelegate{
            context = appDelegate.persistentContainer.viewContext
}
        
    }
    
    func getPopularMovies (page: Int ,completion : @escaping ()->Void) {
        let popularMoviesUrl = URL(string: baseUrl + self.movieUrl + self.popularUrl + self.apiKey + "&language=en-US&page=\(page)")!
        let urlRequest = URLRequest(url: popularMoviesUrl)
        
        URLSession.shared.dataTask(with: urlRequest) { (data, response, error) in
            if error == nil && data != nil {
                guard let jsonMovies = try? JSONSerialization.jsonObject(with: data!, options: .allowFragments) as! [String:AnyObject] else{
                    return
            }
               
                let detailsJson = jsonMovies["results"] as! [[String:AnyObject]]
                    for movieJson in detailsJson{
                    let newMovie = Movie(context : self.context)
                    newMovie.id = (movieJson["id"] as? Int64)!
                    newMovie.title = movieJson["title"] as? String
                    newMovie.rating = (movieJson["vote_average"] as? Float)!
                    newMovie.posterPath = movieJson["poster_path"] as? String
                    newMovie.totalPages = (jsonMovies["total_pages"] as? Int64)!
                        if newMovie.posterPath != nil{
                        ApiHandler.shared.movies.append(newMovie)
                        }
                }

                DispatchQueue.main.async {
                    completion()
                }
        }
    }.resume()
    
    }
    func nowPlayingMovies (page : Int ,completion : @escaping ()->Void) {
        let nowPlayingMoviesUrl = URL(string: baseUrl + self.movieUrl + self.nowPlaying + self.apiKey + "&language=en-US&page=\(page)")!
        let urlRequest = URLRequest(url: nowPlayingMoviesUrl)
        
        URLSession.shared.dataTask(with: urlRequest) { (data, response, error) in
            if error == nil && data != nil {
                guard let jsonMovies = try? JSONSerialization.jsonObject(with: data!, options: .allowFragments) as! [String:AnyObject] else{
                    return
                }
                
                
                
                let detailsJson = jsonMovies["results"] as! [[String:AnyObject]]
                for movieJson in detailsJson{
                    let newMovie = Movie(context : self.context)
                    newMovie.id = (movieJson["id"] as? Int64)!
                    newMovie.title = movieJson["title"] as? String
                    newMovie.rating = (movieJson["vote_average"] as? Float)!
                    newMovie.posterPath = movieJson["poster_path"] as? String
                    newMovie.totalPages = (jsonMovies["total_pages"] as? Int64)!
                    if newMovie.posterPath != nil{
                        ApiHandler.shared.movies.append(newMovie)
                    }
                    
                }
                
                DispatchQueue.main.async {
                    completion()
                }
            }
            }.resume()
        
    }
    func topRatedMovies (page : Int ,completion : @escaping ()->Void) {
        let topRatedMoviesUrl = URL(string: baseUrl + self.movieUrl + self.topRated + self.apiKey + "&language=en-US&page=\(page)")!
        let urlRequest = URLRequest(url: topRatedMoviesUrl)
        
        URLSession.shared.dataTask(with: urlRequest) { (data, response, error) in
            if error == nil && data != nil {
                guard let jsonMovies = try? JSONSerialization.jsonObject(with: data!, options: .allowFragments) as! [String:AnyObject] else{
                    return
                }
                
                
                
                let detailsJson = jsonMovies["results"] as! [[String:AnyObject]]
                for movieJson in detailsJson{
                    let newMovie = Movie(context : self.context)
                    newMovie.id = (movieJson["id"] as? Int64)!
                    newMovie.title = movieJson["title"] as? String
                    newMovie.rating = (movieJson["vote_average"] as? Float)!
                    newMovie.posterPath = movieJson["poster_path"] as? String
                    newMovie.totalPages = (jsonMovies["total_pages"] as? Int64)!
                    if newMovie.posterPath != nil{
                        ApiHandler.shared.movies.append(newMovie)
                    }
                    
                }
                
                DispatchQueue.main.async {
                    completion()
                }
            }
            }.resume()
        
    }
    func upComingMovies (page : Int ,completion : @escaping ()->Void) {
        let upComingMoviesUrl = URL(string: baseUrl + self.movieUrl + self.upComing + self.apiKey + "&language=en-US&page=\(page)")!
        let urlRequest = URLRequest(url: upComingMoviesUrl)
        
        URLSession.shared.dataTask(with: urlRequest) { (data, response, error) in
            if error == nil && data != nil {
                guard let jsonMovies = try? JSONSerialization.jsonObject(with: data!, options: .allowFragments) as! [String:AnyObject] else{
                    return
                }
                
                
                
                let detailsJson = jsonMovies["results"] as! [[String:AnyObject]]
                for movieJson in detailsJson{
                    let newMovie = Movie(context : self.context)
                    newMovie.id = (movieJson["id"] as? Int64)!
                    newMovie.title = movieJson["title"] as? String
                    newMovie.rating = (movieJson["vote_average"] as? Float)!
                    newMovie.posterPath = movieJson["poster_path"] as? String
                    newMovie.totalPages = (jsonMovies["total_pages"] as? Int64)!
                    
                    if newMovie.posterPath != nil{
                        ApiHandler.shared.movies.append(newMovie)
                    }
                }
                
                DispatchQueue.main.async {
                    completion()
                }
            }
            }.resume()
        
    }



    
    func getMovieDetails(movie : Movie , completion : @escaping ()->Void) {
        

        let detailUrl = URL(string: baseUrl + self.movieUrl + "\(movie.id)" + apiKey + "&language=en-US" )
        let urlRequest = URLRequest(url: detailUrl!)
        URLSession.shared.dataTask(with: urlRequest){(data,response,error) in
            if error == nil && data != nil{
                guard let jsonDetails = try? JSONSerialization.jsonObject(with: data!, options: .allowFragments) as! [String:AnyObject] else{
                    return
                }
                movie.id = (jsonDetails["id"] as? Int64)!
                movie.overView = jsonDetails["overview"] as? String
                movie.rating = (jsonDetails["vote_average"] as? Float)!
                movie.releaseDate = jsonDetails["release_date"] as? String
                movie.runTime = (jsonDetails["runtime"] as? Int64)!
                movie.status = jsonDetails["status"] as? String
                movie.posterPath = jsonDetails["poster_path"] as? String
                movie.originalLaguage = jsonDetails["original_language"] as? String
                let moviePrudctions = jsonDetails["production_companies"] as! [[String:AnyObject]]
                for prudcionCompnies in moviePrudctions
                {
                    movie.companies = prudcionCompnies["name"] as? String
                }
                let movieGeners = jsonDetails["genres"] as? [[String:AnyObject]]
                for geners in movieGeners!
                {
                    movie.geners = geners["name"] as? String
                }
                
                movie.backGroundImage = jsonDetails["backdrop_path"] as? String
                               
                DispatchQueue.main.async {
                    completion()
                }

            }
            
        }.resume()
    }
    
    func getMovieTrailers(movie : Movie , completion : @escaping ()->Void){

        let trailerUrl = URL(string: baseUrl + self.movieUrl + "\(movie.id)" + "/videos" + apiKey + "&language=en-US")
        let urlRequest = URLRequest(url: trailerUrl!)
        URLSession.shared.dataTask(with: urlRequest){(data,response,error) in
            if error == nil && data != nil{
                guard let jsonTrailer = try? JSONSerialization.jsonObject(with: data!, options: .allowFragments) as! [String:AnyObject] else{
                        return
                }
                let movieTrailer = jsonTrailer["results"] as! [[String : AnyObject]]
                for trailer in movieTrailer{
                    movie.trailer = trailer["key"] as? String
                }
                
                DispatchQueue.main.async {
                    completion()
                }
            }
        
      }.resume()
    }
    
    func getMovieCharacters(movie : Movie , completion : @escaping ()->Void){

        let charactersUrl = URL(string: baseUrl + self.movieUrl + "\(movie.id)" + credit + apiKey )
        let urlRequest = URLRequest(url:charactersUrl!)
        URLSession.shared.dataTask(with: urlRequest){(data,response,error) in
            if error == nil && data != nil{
                guard let creditJson = try? JSONSerialization.jsonObject(with: data!, options: .allowFragments) as! [String:AnyObject]else{
                    return
                }
                let movieCrew = creditJson["cast"] as! [[String:AnyObject]]
                for crew in movieCrew{
                    let newCharacter = Character(context : self.context)
                    newCharacter.actorName = crew["name"] as? String
                    newCharacter.charaterName = crew["character"] as? String
                    newCharacter.actorImage = crew["profile_path"] as? String
                    newCharacter.id = (crew["id"] as? Int64)!
                    if newCharacter.actorImage != nil{
                    ApiHandler.shared.characters.append(newCharacter)
                    }
                    
                   
                }
                DispatchQueue.main.async {
                    completion()
                    }

                }
            }.resume()
    }
    func getSimilarMovies (page : Int , movie: Movie , completion : @escaping ()->Void) {

        let SimilarMoviesUrl = URL(string: baseUrl + self.movieUrl + "\(movie.id)" + sim + apiKey + "&language=en-US&page=\(page)")
        let urlRequest = URLRequest(url:SimilarMoviesUrl!)
        URLSession.shared.dataTask(with: urlRequest){(data,response,error) in
            if error == nil && data != nil{
                guard let jsonSimilar = try? JSONSerialization.jsonObject(with: data!, options: .allowFragments) as! [String:AnyObject] else{
                    return
                }
                let movieSimilar = jsonSimilar["results"] as! [[String : AnyObject]]
                for similar in movieSimilar{
                let newMovie = Movie(context : self.context)
                    newMovie.id = similar["id"] as! Int64
                    newMovie.title = similar["title"]  as? String
                    newMovie.posterPath = similar["poster_path"] as? String
                    if  newMovie.posterPath != nil{
                        ApiHandler.shared.similarMovies.append(newMovie)

                    }
                    
                }
                
                DispatchQueue.main.async {
                    completion()
                }
            }
            
            }.resume()
        }
    
    func getCharacterInfo(character : Character, completion : @escaping ()->Void){
        let charactersUrl = URL(string: baseUrl + self.personInfoUrl + "\(character.id)" + apiKey + "&language=en-US" )
        let urlRequest = URLRequest(url:charactersUrl!)
        URLSession.shared.dataTask(with: urlRequest){(data,response,error) in
            if error == nil && data != nil{
                guard let infoJson = try? JSONSerialization.jsonObject(with: data!, options: .allowFragments) as! [String:AnyObject]else{
                    return
                }

                
                character.biography = infoJson["biography"] as? String
                character.birthDay = infoJson["birthday"] as? String
                character.deathDay = infoJson["deathday"] as? String
                character.placeOfBirth = infoJson["place_of_birth"] as? String
                
                
                
                DispatchQueue.main.async {
                    completion()
                }
                
            }
            }.resume()

    
    }
    
     
//   ==============================================================================================
    
    func getPopularTvSeries (page : Int , completion : @escaping ()->Void) {
        let popularMoviesUrl = URL(string: baseUrl + self.tvShowUrl + self.popularUrl + self.apiKey + "&language=en-US&page=\(page)")!
        let urlRequest = URLRequest(url: popularMoviesUrl)
        
        URLSession.shared.dataTask(with: urlRequest) { (data, response, error) in
            if error == nil && data != nil {
                guard let jsonTvSeries = try? JSONSerialization.jsonObject(with: data!, options: .allowFragments) as! [String:AnyObject] else{
                    return
                }
               
                
                
                let detailsJson = jsonTvSeries["results"] as! [[String:AnyObject]]
                for tvJson in detailsJson{
                    let newTvSeries = TvShows(context : self.context)
                    newTvSeries.id = (tvJson["id"] as? Int64)!
                    newTvSeries.name = tvJson["name"] as? String
                    newTvSeries.rating = (tvJson["vote_average"] as? Float)!
                    newTvSeries.image = tvJson["poster_path"] as? String
                    if newTvSeries.image != nil {
                         ApiHandler.shared.tvSreies.append(newTvSeries)
                    }
                    
                   
                }
                
                DispatchQueue.main.async {
                    completion()
                }
            }
            }.resume()
        
    }
    
    func getSeriesDetails(series : TvShows , completion : @escaping ()->Void) {
        
        
        let detailUrl = URL(string: baseUrl + self.tvShowUrl + "\(series.id)" + apiKey + "&language=en-US" )
        let urlRequest = URLRequest(url: detailUrl!)
        URLSession.shared.dataTask(with: urlRequest){(data,response,error) in
            if error == nil && data != nil{
                guard let jsonDetails = try? JSONSerialization.jsonObject(with: data!, options: .allowFragments) as! [String:AnyObject] else{
                    return
                }
                series.id = (jsonDetails["id"] as? Int64)!
                series.overView = jsonDetails["overview"] as? String
                series.rating = Float((jsonDetails["vote_average"] as? Double)!)
                series.firstAirDate = jsonDetails["first_air_date"] as? String
                series.lastAirDate = jsonDetails["last_air_date"] as? String
                series.image = jsonDetails["backdrop_path"] as? String
                series.numberOfSeasons = (jsonDetails["number_of_seasons"] as? Int64)!
                series.numberOfEpisodes = (jsonDetails["number_of_episodes"] as? Int64)!
                series.name = jsonDetails["name"] as? String
                let creatorJson = jsonDetails["created_by"] as! [[String:AnyObject]]
                for jsoncreator in creatorJson{
                    series.createdBy = jsoncreator["name"] as? String
                }
                
                let genresJson = jsonDetails["genres"] as? [[String:AnyObject]]
                for jsongenres in genresJson!{
                    series.geners = jsongenres["name"] as? String
                }
                let seriesPrudctions = jsonDetails["production_companies"] as? [[String:AnyObject]]
                for prudcionCompnies in seriesPrudctions!
                {
                    series.prudoctionCompnies = prudcionCompnies["name"] as? String
                }
                series.backGround = jsonDetails["backdrop_path"] as? String
                
                    DispatchQueue.main.async {
                    completion()
                }
                
            }
            
            }.resume()
    }
    
    func getSeriesCharacters(series : TvShows , completion : @escaping ()->Void){
        
        let charactersUrl = URL(string: baseUrl + self.tvShowUrl + "\(series.id)" + credit + apiKey )
        let urlRequest = URLRequest(url:charactersUrl!)
        URLSession.shared.dataTask(with: urlRequest){(data,response,error) in
            if error == nil && data != nil{
                guard let creditJson = try? JSONSerialization.jsonObject(with: data!, options: .allowFragments) as! [String:AnyObject]else{
                    return
                }
                let seriesCrew = creditJson["cast"] as! [[String:AnyObject]]
                for crew in seriesCrew{
                    let newCharacter = Character(context : self.context)
                    newCharacter.actorName = crew["name"] as? String
                    newCharacter.charaterName = crew["character"] as? String
                    newCharacter.actorImage = crew["profile_path"] as? String
                    newCharacter.id = (crew["id"] as? Int64)!
                    if newCharacter.actorImage != nil{
                        ApiHandler.shared.TvSeriesCharacters.append(newCharacter)
                    }
                    
                    
                }
                DispatchQueue.main.async {
                    completion()
                }
                
            }
            }.resume()
    }
    
    func getSimilarSeries (page : Int , series : TvShows , completion : @escaping ()->Void) {
        
        let SimilarSeriesUrl = URL(string: baseUrl + self.tvShowUrl + "\(series.id)" + sim + apiKey + "&language=en-US&page=\(page)")
        let urlRequest = URLRequest(url:SimilarSeriesUrl!)
        URLSession.shared.dataTask(with: urlRequest){(data,response,error) in
            if error == nil && data != nil{
                guard let jsonSimilar = try? JSONSerialization.jsonObject(with: data!, options: .allowFragments) as! [String:AnyObject] else{
                    return
                }
                let seriesSimilar = jsonSimilar["results"] as! [[String : AnyObject]]
                for similar in seriesSimilar{
                    let newSeries = TvShows(context : self.context)
                    newSeries.id = similar["id"] as! Int64
                    newSeries.name = similar["original_name"]  as? String
                    newSeries.image = similar["poster_path"] as? String
                    if  newSeries.image != nil{
                        ApiHandler.shared.tvSimSeries.append(newSeries)
                        
                    }
                    
                }
                
                DispatchQueue.main.async {
                    completion()
                }
            }
            
            }.resume()
    }

    func getSeriesTrailers(series : TvShows , completion : @escaping ()->Void){
        
        let trailerUrl = URL(string: baseUrl + self.tvShowUrl + "\(series.id)" + "/videos" + apiKey + "&language=en-US")
        let urlRequest = URLRequest(url: trailerUrl!)
        URLSession.shared.dataTask(with: urlRequest){(data,response,error) in
            if error == nil && data != nil{
                guard let jsonTrailer = try? JSONSerialization.jsonObject(with: data!, options: .allowFragments) as! [String:AnyObject] else{
                    return
                }
                let seriesTrailer = jsonTrailer["results"] as! [[String : AnyObject]]
                for trailer in seriesTrailer{
                    series.trailer = trailer["key"] as? String
                }
                
                DispatchQueue.main.async {
                    completion()
                }
            }
            
            }.resume()
    }


    func topRatedSeries (page : Int , completion : @escaping ()->Void){

        let topRatedUrl = URL(string : baseUrl + self.tvShowUrl + self.topRated + apiKey + "&language=en-US&page=\(page)" )
        let urlRequest =  URLRequest(url: topRatedUrl!)
        URLSession.shared.dataTask(with: urlRequest){(data,response,error) in
            if error == nil && data != nil{
                guard let jsonTopRated = try? JSONSerialization.jsonObject(with: data!, options: .allowFragments) as! [String:AnyObject] else{
                    return
                }
                let detailsJson = jsonTopRated["results"] as! [[String:AnyObject]]
                for tvJson in detailsJson{
                    let newSeries = TvShows(context : self.context)
                    newSeries.id = (tvJson["id"] as? Int64)!
                    newSeries.name = tvJson["original_name"] as? String
                    newSeries.rating = (tvJson["vote_average"] as? Float)!
                    newSeries.image = tvJson["poster_path"] as? String
                    newSeries.pages = (jsonTopRated["total_pages"] as? Int64)!
                    if newSeries.image != nil{
                        ApiHandler.shared.tvSreies.append(newSeries)
                    }
                    
                }
                
                DispatchQueue.main.async {
                    completion()
                }
            }
            }.resume()
    }
    

  }
