//
//  extraCellCollectionViewCell.swift
//  imdb
//
//  Created by maher deeb on 25/07/2017.
//  Copyright © 2017 maher deeb. All rights reserved.
//

import UIKit

class ExtraCellCollectionViewCell: UICollectionViewCell {
    
    @IBOutlet weak var extraImage: UIImageView!
    @IBOutlet weak var extraLabel: UILabel!
    @IBOutlet weak var reviews: UITextView!
    @IBOutlet weak var reviewNumber: UILabel!
    let imagePath = "https://image.tmdb.org/t/p/w300/"
    var character : Character?{
        didSet{
            extraLabel.text = character?.actorName
            
            let characterPhotoUrl = URL(string: imagePath +  (character?.actorImage)! )
            let request = URLRequest(url: characterPhotoUrl!)
            self.extraImage.image = nil
            URLSession.shared.dataTask(with: request) { (data, response, error) in
                if data != nil {
                    let image = UIImage(data: data!)
                    DispatchQueue.main.async {
                        self.extraImage.image = image
                        
                    }
                    
                }
                }.resume()
        }
    }
    var movie : Movie?{
        didSet{
            extraLabel.text = self.movie?.title
            
            let moviePhotoUrl = URL(string: imagePath + (self.movie?.posterPath)! )
            let request = URLRequest(url: moviePhotoUrl!)
            self.extraImage.image = nil
            URLSession.shared.dataTask(with: request) { (data, response, error) in
                if data != nil {
                    let image = UIImage(data: data!)
                    DispatchQueue.main.async {
                        self.extraImage.image = image
                    }
                    
                }
                }.resume()
        }
    }

          
    
}
