//
//  CharacterViewController.swift
//  imdb
//
//  Created by maher deeb on 26/07/2017.
//  Copyright © 2017 maher deeb. All rights reserved.
//

import UIKit

class CharacterViewController: UIViewController {
    
    
    @IBOutlet weak var characterImage: UIImageView!
    @IBOutlet weak var characterName: UILabel!
    @IBOutlet weak var characterBirthDay: UILabel!
    @IBOutlet weak var characterPlaceOfBirth: UILabel!
    @IBOutlet weak var characterDeathDay: UILabel!
    @IBOutlet weak var characterBiography: UITextView!
    let imagePath = "https://image.tmdb.org/t/p/w300/"
    
    var character : Character?
    
    override func viewWillAppear(_ animated: Bool) {
        ApiHandler.shared.getCharacterInfo(character: character!){
            self.title = self.character?.actorName
            
            self.characterName.text = "Character Name: \n" + (self.character?.charaterName)!
            if let  birthday = self.character?.birthDay {
               self.characterBirthDay.text = "Birth Date: \n" + birthday
            }
            else{
                return self.characterBirthDay.text = ""
            }
            
            if let placeOfBirth = self.character?.placeOfBirth{
                self.characterPlaceOfBirth.text = "Place Of Birth: \n" + placeOfBirth
            }
            else{
                 self.characterPlaceOfBirth.text = ""
            }
            if let deathDay =  self.character?.deathDay{
                self.characterDeathDay.text = "Death Date: \n" + deathDay
            }else{
                self.characterDeathDay.text = ""
            }
            
            self.characterBiography.text = self.character?.biography
            let characterPhotoUrl = URL(string: self.imagePath +  (self.character?.actorImage)! )
            let request = URLRequest(url: characterPhotoUrl!)
            self.characterImage.image = nil
            URLSession.shared.dataTask(with: request) { (data, response, error) in
                if data != nil {
                    let image = UIImage(data: data!)
                    DispatchQueue.main.async {
                        self.characterImage.image = image
                        
                    }
                    
                }
                }.resume()
            
        }
        
    }
    
    
    
}


